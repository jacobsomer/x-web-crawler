autofollow/
├── autofollow/
│ ├── **init**.py
│ ├── agent.py
│ ├── twitter.py
│ ├── github.py
│ └── common.py
├── tests/
│ ├── **init**.py
│ ├── test_twitter.py
│ └── test_github.py
├── setup.py
├── README.md
├── LICENSE
└── requirements.txt
